// +build ignore
package foo

func Bar(baz string, qux *Zip) (*Zap, Zop) {
	ziz := mop(3, "hello world")
}

type Qaz struct {
	Buz string
	Mat *Foo
}
