"this string does not end
